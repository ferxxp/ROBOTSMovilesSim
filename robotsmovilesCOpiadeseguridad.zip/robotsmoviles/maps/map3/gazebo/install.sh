#!/bin/sh
sudo cp kobuki_args.launch.xml /opt/ros/indigo/share/turtlebot_gazebo/launch/includes
sudo cp map3.world /opt/ros/indigo/share/turtlebot_gazebo/worlds
sudo cp map3_world.launch /opt/ros/indigo/share/turtlebot_gazebo/launch
